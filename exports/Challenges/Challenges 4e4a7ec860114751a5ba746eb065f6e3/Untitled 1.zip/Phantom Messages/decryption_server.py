from socket import AF_INET, SOCK_STREAM, socket, SOL_SOCKET, SO_REUSEADDR
import base64
from hashlib import md5
from datetime import datetime
from os import remove, path

HOST = '0.0.0.0'
PORT = 9002 
LOG_FILE = "./decryption_server.log"
KEY_FILE = "./key.txt"
key: str 

class Logger:
    @staticmethod
    def log(message):
        with open(LOG_FILE, 'a') as f:
            now = datetime.now()
            f.write(now.strftime("%d/%m/%Y %H:%M:%S") + "\t")
            f.write(message + '\n')    


def decrypt(encrypted):
    global key
    factor = len(encrypted) // len(key) + 1 
    key = key * factor
    key_bytes = key.encode()

    enc_bytes = base64.b64decode(encrypted)
    dec_bytes = bytearray()

    for i in range(len(enc_bytes)):
        dec_bytes.append(enc_bytes[i] ^ key_bytes[i])
        Logger.log(f"part {i} hexdigest: {md5(dec_bytes).hexdigest()}")
    decrypted = dec_bytes.decode()
    Logger.log("Message fully decrypted, ready to send...")
    return decrypted


def main():
    global key
    remove(LOG_FILE) if path.exists(LOG_FILE) else None
    
    with open(KEY_FILE) as file:
        key = file.read()
        key = key.strip()


    s = socket(AF_INET, SOCK_STREAM)
    s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    Logger.log(f"Server listening on {HOST}:{PORT}")
    
    while True:
        s.listen(1)
        Logger.log("Waiting connection...")

        connection, addr = s.accept()
        Logger.log(f"Connection received from {addr[0]}:{addr[1]}")

        ciphertext = connection.recv(1024).decode().strip()
        Logger.log(f"Received encrypted message {ciphertext}")

        plaintext = decrypt(ciphertext)
        connection.sendall(plaintext.encode())
        Logger.log(f"Decrypted message sent!")


if __name__ == '__main__':
    main()

